//
//  TabItem.swift
//  StyleSphere
//
//  Created by MacBook Pro on 28/05/24.
//

import Foundation

struct TabItem: Hashable {
    var mainImage: String
    var hoveredImage: String
    var Title: String
  
}
