//
//  LooksView.swift
//  StyleSphere
//
//  Created by MacBook Pro on 27/05/24.
//

import SwiftUI

struct LooksView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

#Preview {
    LooksView()
}
